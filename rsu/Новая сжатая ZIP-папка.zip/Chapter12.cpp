#include "Chapter12.h"
#include <iostream>
using namespace std;



// Task 1

Cow::Cow() : name("\0"), hobby(nullptr), weight(0) {
}
Cow::Cow(const char* nm, const char* ho, double wt) : weight(wt) {
	int i = 0;
	for (; i < 19 and '\0' != *(nm + i); ++i)
		name[i] = *(nm + i);
	name[i] = '\0';

	int len = strlen(ho);
	hobby = new char[len + 1];
	strcpy_s(hobby, len + 1, ho);

}
Cow::Cow(const Cow& c) : weight(c.weight) {
	strcpy_s(name, c.name);
	int len = strlen(c.hobby);
	hobby = new char[len + 1];
	strcpy_s(hobby, len + 1, c.hobby);
}
Cow::~Cow() {
	delete[] hobby;
	hobby = nullptr;
}
Cow& Cow::operator=(const Cow& c) {
	if (this == &c)
		return *this;
	delete[] hobby;
	strcpy_s(name, c.name);
	int len = strlen(c.hobby);
	hobby = new char[len + 1];
	strcpy_s(hobby, len + 1, c.hobby);
	weight = c.weight;
	return *this;
}
void Cow::ShowCow() const {
	cout << "\nName: " << name << ", hobby: " << hobby << ", weight: " << weight << endl;
}
ostream& operator<<(ostream& os, const Cow& c) {
	if (c.hobby)
		os << "\nName: " << c.name << ", hobby: " << c.hobby << ", weight: " << c.weight << endl;
	else
		os << "\nName: " << c.name << ", no hobby, weight: " << c.weight << endl;
	return os;
}


// Task 2

int String::num_strings = 0;
int String::HowMany()
{
	return num_strings;
}
String::String(const char* s)
{
	len = strlen(s);          
	str = new char[len + 1];      
	strcpy_s(str, sizeof(s-1), s);          
	num_strings++;               
}
String::String()                  
{
	len = 4;
	str = new char[1];
	str[0] = '\0';               
	num_strings++;
}
String::String(const String& st)
{
	num_strings++;             
	len = st.len;             
	str = new char[len + 1]; 
	strcpy_s(str, sizeof(st.str), st.str);
}
String::~String()                   
{
	--num_strings;              
	delete[] str;         
}
String& String::operator=(const String& st)
{
	if (this == &st)
		return *this;
	delete[] str;
	len = st.len;
	str = new char[len + 1];
	strcpy_s(str, sizeof(st.str), st.str);
	return *this;
}
String& String::operator=(const char* s)
{
	delete[] str;
	len = strlen(s);
	str = new char[len + 1];
	strcpy_s(str, sizeof(s), s);
	return *this;
}
char& String::operator[](int i)
{
	return str[i];
}
const char& String::operator[](int i) const
{
	return str[i];
}
bool operator<(const String& st1, const String& st2)
{
	return (strcmp(st1.str, st2.str) < 0);
}
bool operator>(const String& st1, const String& st2)
{
	return st2 < st1;
}
bool operator==(const String& st1, const String& st2)
{
	return (strcmp(st1.str, st2.str) == 0);
}
ostream& operator<<(ostream& os, const String& st)
{
	os << st.str;
	return os;
}
istream& operator>>(istream& is, String& st)
{
	char temp[String::CINLIM];
	is.get(temp, String::CINLIM);
	if (is)
		st = temp;
	while (is && is.get() != '\n')
		continue;
	return is;
}
String String::operator+(const String& second) const {
	int Len = strlen(str) + strlen(second.str);
	char* Str = new char[Len + 1]; 
	strcpy_s(Str, sizeof(str), str);
	strcat_s(Str, sizeof(second.str), second.str);
	Str[Len] = '\0';
	String Buf(Str);
	delete[]Str;
	return Buf;
}
String String::operator+(const char* second) const {
	int Len = strlen(str) + strlen(second);
	char* Str = new char[Len + 1]; 
	strcpy_s(Str, sizeof(str), str);
	strcat_s(Str, sizeof(second), second);
	Str[Len] = '\0';
	String Buf(Str);
	delete[]Str;
	return Buf;
}
void String::stringlow() { 
	for (int i = 0; i < len; ++i)
		if (isupper(str[i]))
			str[i] = tolower(str[i]);
}
void String::stringup() { 
	for (int i = 0; i < len; ++i)
		if (islower(str[i]))
			str[i] = toupper(str[i]);
}
int String::has(char ch)const { 
	int num = 0;
	for (int i = 0; i < len; ++i)
		if (ch == (str[i]))
			++num;
	return num;
}
String operator+(const char* second, const String& Strin) {
	int Len = strlen(Strin.str) + strlen(second);
	char* Str = new char[Len + 1]; 
	strcpy_s(Str, sizeof(second), second);
	strcat_s(Str, sizeof(Strin.str), Strin.str);
	Str[Len] = '\0';
	String Buf(Str);
	delete[]Str;
	return Buf;
}